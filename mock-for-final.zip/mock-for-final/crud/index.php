<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
        .wrapper{
            width: 900px;
            margin: 0 auto;
        }
        table tr td:last-child{
            width: 120px;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="mt-5 mb-3 clearfix">
                        <h2 class="float-start">Students Detail</h2>
                        <a href="create.php" class="btn btn-success float-end"><i class="fa fa-plus"></i> Add New Student</a>
                    </div>
                    <?php
                   
                    require_once "config.php";
                    
                   
                    $sql = "SELECT * FROM students";
                    if($result = mysqli_query($link, $sql)){
                        if(mysqli_num_rows($result) > 0){
                            echo '<table class="table table-bordered table-striped">';
                                echo "<thead>";
                                    echo "<tr>";
                                        echo '<th class="text-nowrap text-center">#</th>';
                                        echo '<th class="text-nowrap text-center">First Name</th>';
                                        echo '<th class="text-nowrap text-center">Last Name</th>';
                                        echo '<th class="text-nowrap text-center">Email Address</th>';
                                        echo '<th class="text-nowrap text-center">Phone Number</th>';
                                        echo '<th class="text-nowrap text-center">Actions</th>';
                                    echo "</tr>";
                                echo "</thead>";
                                echo "<tbody>";
                                while($row = mysqli_fetch_array($result)){
                                    echo "<tr>";
                                        echo '<td class="text-nowrap text-center">' . $row['id'] . "</td>";
                                        echo '<td class="text-nowrap text-center">' . $row['fname'] . "</td>";
                                        echo '<td class="text-nowrap text-center">' . $row['lname'] . "</td>";
                                        echo '<td class="text-nowrap text-center">' . $row['email'] . "</td>";
                                        echo '<td class="text-nowrap text-center">' . $row['phone'] . "</td>";
                                        echo '<td class="text-nowrap text-center">
                                                <a href="read.php?id=' . $row['id'] . '" class="mr-2" title="View Record" data-toggle="tooltip"><span class="fa fa-eye fs-5 text-secondary"></span></a>
                                                <a href="update.php?id=' . $row['id'] . '" class="mr-2" title="Update Record" data-toggle="tooltip"><span class="fa fa-pencil fs-5 text-success"></span></a>
                                                <a href="delete.php?id=' . $row['id'] . '" class="" title="Delete Record" data-toggle="tooltip"><span class="fa fa-trash fs-5 text-danger"></span></a>
                                              </td>';
                                }
                                echo "</tbody>";                            
                            echo "</table>";
                            // Free result set
                            mysqli_free_result($result);
                        } else{
                            echo '<div class="alert alert-danger"><em>No records were found.</em></div>';
                        }
                    } else{
                        echo "Oops! Something went wrong. Please try again later.";
                    }
 
                    // Close connection
                    mysqli_close($link);
                    ?>
                </div>
            </div>        
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.min.js" integrity="sha384-Rx+T1VzGupg4BHQYs2gCW9It+akI2MM/mndMCy36UVfodzcJcF0GGLxZIzObiEfa" crossorigin="anonymous"></script>
</body>
</html>